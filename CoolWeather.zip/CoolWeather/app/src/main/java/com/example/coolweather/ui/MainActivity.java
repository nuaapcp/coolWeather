package com.example.coolweather.ui;


import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.example.coolweather.R;
import com.example.coolweather.network.Api;
import com.example.coolweather.network.model.ProvinceResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends BaseActivity {
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final TextView textView = findViewById(R.id.text1);
        textView.setText("获取省份");

        final TextView textView2 = findViewById(R.id.text2);
        textView2.setText("click here");
        textView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Api.getApiService("http://guolin.tech/api/").getProvince2().enqueue(new Callback<List<ProvinceResponse>>() {
                    @Override
                    public void onResponse(Call<List<ProvinceResponse>> call, Response<List<ProvinceResponse>> response) {
                        if (response.body() != null) {
                            textView2.setText(response.body().get(0).getName());
                        }
                    }

                    @Override
                    public void onFailure(Call<List<ProvinceResponse>> call, Throwable t) {
                        Log.d(TAG, "onFailure: get provinces failed!");
                    }
                });
            }
        });
    }
}
