package com.example.coolweather.common;

public class CommonConstants {
    public final static String COOLWEATHER_DB_NAME = "coolweather_db_name";
    public final static String heFengApiKey = "492f96b4ebd84ac7b0b95cba23b4bedb";
}
